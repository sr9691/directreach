/**
 * Existing Assets Manager
 * 
 * Manages Step 3: Upload Existing Assets
 * - File upload via click and drag-and-drop
 * - Asset list display
 * - Asset deletion
 * 
 * @package DirectReach_Campaign_Builder
 * @subpackage Journey_Circle
 * @since 2.0
 */

(function($) {
    'use strict';

    class ExistingAssetsManager {
        constructor(workflow) {
            this.workflow = workflow;
            this.assets = [];
            this.allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
            this.maxFileSize = 10 * 1024 * 1024; // 10MB

            this.init();
        }

        init() {
            this.bindEvents();
            this.loadFromWorkflow();
            console.log('Existing Assets Manager initialized');
        }

        bindEvents() {
            // File input change
            $('#jc-asset-input').on('change', (e) => this.handleFileSelect(e));

            // Click on upload area should trigger file input
            $('#jc-asset-upload-area').on('click', (e) => {
                // Don't trigger if clicking on the input itself
                if (e.target.id !== 'jc-asset-input') {
                    e.preventDefault();
                    e.stopPropagation();
                    $('#jc-asset-input').trigger('click');
                }
            });

            // Drag and drop
            this.initDragDrop('#jc-asset-upload-area');

            // URL asset input
            $('.jc-add-asset-url-btn').on('click', () => this.addAssetURL());
            $('#jc-asset-url-input').on('keypress', (e) => {
                if (e.which === 13) {
                    e.preventDefault();
                    this.addAssetURL();
                }
            });

            // Delete asset (delegated)
            $(document).on('click', '.jc-asset-delete', (e) => {
                e.preventDefault();
                const index = $(e.currentTarget).data('index');
                this.deleteAsset(index);
            });

            // Restore state
            $(document).on('jc:restoreState', (e, state) => {
                if (state.existingAssets && state.existingAssets.length > 0) {
                    this.assets = state.existingAssets;
                    this.renderAssetList();
                    this.updateAssetCount();
                }
            });
        }

        /**
         * Handle file selection from input
         */
        handleFileSelect(event) {
            const files = event.target.files;

            if (!files || files.length === 0) {
                return;
            }

            Array.from(files).forEach(file => {
                this.uploadFile(file);
            });

            // Reset input so same file can be selected again
            event.target.value = '';
        }

        /**
         * Upload a file - uses REST media for uploadable types, reads HTML/text inline
         */
        async uploadFile(file) {
            // Validate file
            const validation = this.validateFile(file);
            if (!validation.valid) {
                this.workflow.showNotification(validation.message, 'error');
                return;
            }

            // Show loading state
            const loadingId = this.addLoadingAsset(file.name);

            try {
                // Use WordPress REST API media endpoint
                const formData = new FormData();
                formData.append('file', file);
                formData.append('title', file.name);

                // Get the base REST URL - strip custom namespace to get wp-json base
                let restBase = this.workflow.config.restUrl;
                const wpJsonIdx = restBase.indexOf('/wp-json/');
                if (wpJsonIdx !== -1) {
                    restBase = restBase.substring(0, wpJsonIdx + '/wp-json'.length);
                }
                const mediaUrl = restBase + '/wp/v2/media';

                console.log('Uploading asset to:', mediaUrl);

                const response = await fetch(mediaUrl, {
                    method: 'POST',
                    headers: {
                        'X-WP-Nonce': this.workflow.config.restNonce
                    },
                    body: formData
                });

                // Remove loading state
                this.removeLoadingAsset(loadingId);

                if (response.ok) {
                    const data = await response.json();

                    // Add uploaded file to assets
                    this.assets.push({
                        type: 'file',
                        value: data.source_url || data.guid?.rendered || '',
                        name: file.name,
                        fileId: data.id,
                        size: file.size,
                        mimeType: file.type,
                        _extractionStatus: 'processing',
                        _extractionChars: 0,
                        addedAt: new Date().toISOString()
                    });

                    this.renderAssetList();
                    this.updateAssetCount();
                    this.saveToWorkflow();
                    this.updateNextButton();

                    this.workflow.showNotification('Asset "' + file.name + '" uploaded — extracting content...', 'info');

                    // Trigger extraction immediately in background
                    this.triggerExtraction(data.id, file.name);
                } else {
                    let errorMsg = 'Upload failed (HTTP ' + response.status + ')';
                    try {
                        const errData = await response.json();
                        errorMsg = (errData.message || errorMsg);
                    } catch(e) {}
                    throw new Error(errorMsg);
                }

            } catch (error) {
                this.removeLoadingAsset(loadingId);
                this.workflow.showNotification('Error uploading "' + file.name + '": ' + error.message, 'error');
                console.error('Asset upload error:', error);
            }
        }

        /**
         * Add a URL as an existing asset
         */
        addAssetURL() {
            const url = $('#jc-asset-url-input').val().trim();

            if (!url) {
                this.workflow.showNotification('Please enter a URL', 'error');
                return;
            }

            // Basic URL validation
            try {
                new URL(url);
            } catch (_) {
                this.workflow.showNotification('Please enter a valid URL (e.g. https://example.com/page)', 'error');
                return;
            }

            // Check for duplicates
            if (this.assets.some(a => a.type === 'url' && a.value === url)) {
                this.workflow.showNotification('This URL has already been added', 'error');
                return;
            }

            // Extract a readable name from the URL
            let name = url;
            try {
                const parsed = new URL(url);
                const path = parsed.pathname.replace(/\/$/, '');
                name = path && path !== '/'
                    ? decodeURIComponent(path.split('/').pop().replace(/[-_]/g, ' '))
                    : parsed.hostname;
            } catch (_) { /* keep full url as name */ }

            this.assets.push({
                type: 'url',
                value: url,
                name: name,
                fileId: null,
                size: null,
                mimeType: null,
                addedAt: new Date().toISOString()
            });

            // Update UI
            $('#jc-asset-url-input').val('');
            this.renderAssetList();
            this.updateAssetCount();
            this.saveToWorkflow();

            this.workflow.showNotification('Asset URL added successfully', 'success');
        }

        /**
         * Validate file before upload
         */        validateFile(file) {
            // Check file size
            if (file.size > this.maxFileSize) {
                return {
                    valid: false,
                    message: `File "${file.name}" exceeds maximum size of 10MB`
                };
            }

            // Check file type
            if (this.allowedTypes.length > 0 && !this.allowedTypes.includes(file.type)) {
                return {
                    valid: false,
                    message: `File type "${file.type || 'unknown'}" is not supported. Allowed: PDF, DOCX`
                };
            }

            return { valid: true };
        }

        /**
         * Add loading placeholder
         */
        addLoadingAsset(fileName) {
            const loadingId = 'loading-' + Date.now();
            const $list = $('#jc-asset-list');

            // Remove empty state
            $list.find('.jc-empty-state').hide();

            $list.append(`
                <div class="jc-asset-item jc-loading" id="${loadingId}">
                    <div class="jc-asset-icon">
                        <i class="fas fa-spinner fa-spin"></i>
                    </div>
                    <div class="jc-asset-info">
                        <span class="jc-asset-name">${this.escapeHtml(fileName)}</span>
                        <span class="jc-asset-status">Uploading...</span>
                    </div>
                </div>
            `);

            return loadingId;
        }

        /**
         * Remove loading placeholder
         */
        removeLoadingAsset(loadingId) {
            $(`#${loadingId}`).remove();
        }

        /**
         * Render the asset list with extraction status badges
         */
        renderAssetList() {
            const $list = $('#jc-asset-list');
            $list.empty();

            if (this.assets.length === 0) {
                $list.html(`
                    <div class="jc-empty-state">
                        <i class="fas fa-inbox"></i>
                        <p>No assets added yet. Upload files or add URLs above.</p>
                    </div>
                `);
                return;
            }

            this.assets.forEach((asset, index) => {
                const icon = this.getFileIcon(asset);
                const size = this.formatFileSize(asset.size);
                const isUrl = asset.type === 'url';
                const meta = isUrl
                    ? `<a href="${this.escapeHtml(asset.value)}" target="_blank" rel="noopener noreferrer" class="jc-asset-url-link">${this.escapeHtml(asset.value)}</a>`
                    : (size ? `<span class="jc-asset-meta">${size}</span>` : '');

                // Extraction status badge
                const statusBadge = this.getExtractionBadge(asset);

                $list.append(`
                    <div class="jc-asset-item" data-index="${index}" data-file-id="${asset.fileId || ''}">
                        <div class="jc-asset-icon">
                            <i class="fas ${icon}"></i>
                        </div>
                        <div class="jc-asset-info">
                            <span class="jc-asset-name">${this.escapeHtml(asset.name)}</span>
                            ${meta}
                        </div>
                        <div class="jc-asset-extraction-status">
                            ${statusBadge}
                        </div>
                        <div class="jc-asset-actions">
                            <button class="jc-asset-delete" data-index="${index}" title="Remove asset">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                `);
            });

            // Check extraction status for file assets that have fileIds
            this.checkExtractionStatus();
        }

        /**
         * Get extraction status badge HTML for an asset
         */
        getExtractionBadge(asset) {
            const status = asset._extractionStatus || 'unknown';
            const chars = asset._extractionChars || 0;

            switch (status) {
                case 'completed':
                case 'extracted':
                    const charsDisplay = chars > 1000
                        ? (chars / 1000).toFixed(1) + 'k'
                        : chars;
                    return `<span class="jc-extraction-badge jc-extraction-success" title="Content extracted (${chars} chars)">
                        <i class="fas fa-check-circle"></i> Extracted${chars ? ' (' + charsDisplay + ' chars)' : ''}
                    </span>`;
                case 'processing':
                    return `<span class="jc-extraction-badge jc-extraction-processing" title="Extracting content...">
                        <i class="fas fa-spinner fa-spin"></i> Extracting...
                    </span>`;
                case 'failed':
                    return `<span class="jc-extraction-badge jc-extraction-failed" title="Extraction failed — content will not be used for AI generation">
                        <i class="fas fa-exclamation-triangle"></i> Failed
                    </span>`;
                case 'pending':
                    return `<span class="jc-extraction-badge jc-extraction-pending" title="Content will be extracted when titles are generated">
                        <i class="fas fa-clock"></i> Pending
                    </span>`;
                default:
                    // Files and URLs — status not yet known, show pending
                    return `<span class="jc-extraction-badge jc-extraction-pending" title="Content will be extracted when titles are generated">
                        <i class="fas fa-clock"></i> Pending
                    </span>`;
            }
        }

        /**
         * Check extraction status for all file assets via REST API
         */
        async checkExtractionStatus() {
            const fileAssets = this.assets.filter(a => a.type === 'file' && a.fileId);
            if (fileAssets.length === 0) return;

            const fileIds = fileAssets.map(a => a.fileId);

            try {
                const response = await fetch(`${this.workflow.config.restUrl}/ai/extraction-status`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': this.workflow.config.restNonce
                    },
                    body: JSON.stringify({ file_ids: fileIds })
                });

                if (!response.ok) return;

                const data = await response.json();
                if (!data.items || !data.items.length) return;

                let updated = false;

                data.items.forEach(item => {
                    const asset = this.assets.find(a => a.fileId === item.fileId);
                    if (asset) {
                        const oldStatus = asset._extractionStatus;
                        asset._extractionStatus = item.status === 'completed' ? 'extracted' : item.status;
                        asset._extractionChars = item.chars || 0;

                        if (oldStatus !== asset._extractionStatus) {
                            updated = true;
                        }
                    }
                });

                // Re-render badges if any status changed (without re-checking to avoid loop)
                if (updated) {
                    this.assets.forEach((asset, index) => {
                        const $item = $(`#jc-asset-list .jc-asset-item[data-index="${index}"]`);
                        if ($item.length) {
                            $item.find('.jc-asset-extraction-status').html(this.getExtractionBadge(asset));
                        }
                    });
                }

                // Console log summary
                const extracted = data.items.filter(i => i.status === 'completed').length;
                const pending = data.items.filter(i => !i.status || i.status === 'pending' || i.status === 'none').length;
                const failed = data.items.filter(i => i.status === 'failed').length;
                const totalChars = data.items.reduce((sum, i) => sum + (i.chars || 0), 0);

                console.log(`[JC Assets] Extraction status: ${extracted}/${fileAssets.length} extracted (${totalChars.toLocaleString()} chars), ${pending} pending, ${failed} failed`);

            } catch (error) {
                console.warn('[JC Assets] Could not check extraction status:', error.message);
            }
        }

        /**
         * Trigger server-side extraction for a file asset immediately after upload.
         * Disables the Next button until extraction completes.
         */
        async triggerExtraction(fileId, fileName) {
            try {
                console.log(`[JC Assets] Triggering extraction for "${fileName}" (ID: ${fileId})...`);

                const response = await fetch(`${this.workflow.config.restUrl}/ai/extract-asset`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': this.workflow.config.restNonce
                    },
                    body: JSON.stringify({ file_id: fileId })
                });

                const data = await response.json();
                const asset = this.assets.find(a => a.fileId === fileId);

                if (data.success && data.status === 'completed') {
                    console.log(`[JC Assets] ✅ Extraction complete for "${fileName}": ${data.chars.toLocaleString()} chars`);

                    if (asset) {
                        asset._extractionStatus = 'extracted';
                        asset._extractionChars = data.chars || 0;
                    }

                    this.workflow.showNotification(`"${fileName}" content extracted (${data.chars.toLocaleString()} chars)`, 'success');
                } else {
                    console.error(`[JC Assets] ❌ Extraction failed for "${fileName}":`, data.error || 'Unknown error');

                    if (asset) {
                        asset._extractionStatus = 'failed';
                        asset._extractionChars = 0;
                    }

                    this.workflow.showNotification(`Content extraction failed for "${fileName}". The file may still be used but with reduced effectiveness.`, 'error');
                }
            } catch (error) {
                console.error(`[JC Assets] Extraction error for "${fileName}":`, error);

                const asset = this.assets.find(a => a.fileId === fileId);
                if (asset) {
                    asset._extractionStatus = 'failed';
                    asset._extractionChars = 0;
                }

                this.workflow.showNotification(`Content extraction error for "${fileName}".`, 'error');
            }

            // Update badge and Next button regardless of outcome
            this.renderAssetList();
            this.updateNextButton();
        }

        /**
         * Disable/enable the Next button based on whether any assets are still extracting.
         */
        updateNextButton() {
            const extracting = this.assets.some(a => a._extractionStatus === 'processing');
            const $nextBtn = $('.jc-next-btn');

            if (extracting) {
                $nextBtn.prop('disabled', true).addClass('jc-btn-extracting');
                // Add a tooltip-style message if not already present
                if (!$nextBtn.data('original-text')) {
                    $nextBtn.data('original-text', $nextBtn.html());
                }
                $nextBtn.html('<i class="fas fa-spinner fa-spin"></i> Extracting content...');
            } else {
                $nextBtn.prop('disabled', false).removeClass('jc-btn-extracting');
                const original = $nextBtn.data('original-text');
                if (original) {
                    $nextBtn.html(original);
                    $nextBtn.removeData('original-text');
                }
            }
        }

        /**
         * Delete an asset
         */
        deleteAsset(index) {
            if (index < 0 || index >= this.assets.length) return;

            const asset = this.assets[index];
            if (!confirm(`Remove "${asset.name}"?`)) return;

            this.assets.splice(index, 1);
            this.renderAssetList();
            this.updateAssetCount();
            this.saveToWorkflow();
            this.updateNextButton();

            this.workflow.showNotification('Asset removed', 'info');
        }

        /**
         * Update asset count badge
         */
        updateAssetCount() {
            $('.jc-asset-count').text(this.assets.length);
        }

        /**
         * Save assets to workflow state
         */
        saveToWorkflow() {
            this.workflow.updateState('existingAssets', this.assets);
        }

        /**
         * Load assets from workflow state
         */
        loadFromWorkflow() {
            const existingAssets = this.workflow.getState('existingAssets');
            if (existingAssets && existingAssets.length > 0) {
                this.assets = existingAssets;

                // Reset any stuck 'processing' states from a previous page load
                this.assets.forEach(a => {
                    if (a._extractionStatus === 'processing') {
                        a._extractionStatus = 'pending';
                    }
                });

                this.renderAssetList();
                this.updateAssetCount();
            }
        }

        /**
         * Initialize drag and drop
         */
        initDragDrop(dropZoneSelector) {
            const $dropZone = $(dropZoneSelector);

            // Prevent default browser behavior for drag events
            $dropZone.on('dragover dragenter', function(e) {
                e.preventDefault();
                e.stopPropagation();
                $(this).addClass('jc-drag-over');
            });

            $dropZone.on('dragleave', function(e) {
                e.preventDefault();
                e.stopPropagation();
                $(this).removeClass('jc-drag-over');
            });

            $dropZone.on('drop', (e) => {
                e.preventDefault();
                e.stopPropagation();
                $dropZone.removeClass('jc-drag-over');

                const files = e.originalEvent.dataTransfer.files;
                if (files.length > 0) {
                    Array.from(files).forEach(file => {
                        this.uploadFile(file);
                    });
                }
            });
        }

        /**
         * Get appropriate icon for file type
         */
        getFileIcon(asset) {
            if (asset.type === 'url') return 'fa-link';
            if (!asset.mimeType && !asset.name) return 'fa-file';

            const ext = asset.name ? asset.name.split('.').pop().toLowerCase() : '';

            if (asset.mimeType === 'application/pdf' || ext === 'pdf') {
                return 'fa-file-pdf';
            }
            if (asset.mimeType?.includes('word') || ['doc', 'docx'].includes(ext)) {
                return 'fa-file-word';
            }
            return 'fa-file';
        }

        /**
         * Format file size
         */
        formatFileSize(bytes) {
            if (!bytes) return '';
            if (bytes < 1024) return bytes + ' B';
            if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
            return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
        }

        /**
         * Escape HTML
         */
        escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
    }

    // Initialize when workflow is ready
    $(document).ready(function() {
        if (window.drJourneyCircle) {
            window.drExistingAssetsManager = new ExistingAssetsManager(window.drJourneyCircle);
        }
    });

})(jQuery);